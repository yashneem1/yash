from flask import Flask, render_template, request

app = Flask(__name__)

# Example whitelist
WHITELIST = {"2uGRTmg81V2bsLX3MqBTFgZzcPC4vYNsqV8cTexaVeH8"
,"5UEpQw1eGKU89oifi668FpwsWYPBkFKGq3YRraEKrBXp"
,"JCLNw5wWdnv5mvNLjUKLevAvRTst1SomeigQ2uo4snu1"
,"8A3yQ1rjzZk572YLtVyEvHsPs1tQKfrAzcLu2W3o8t8G"
,"DGX3yKS3xnVsNUBy3pjqc6uFwan47Kyb7zneWpJTKNbb"
,"2rsrazzR3eNm1CtK5qk3niq2jUutF24tLhmUGBaWh5Qa"
,"9LuY4wGhiEGyqUg5fsqaeU3VwY5xf56zwJfPvL7ZkU5u"
,"CapdQv9UotbPDhTHJyfVDuPAMbwMShpU9wdzfnLCJ1X7"
,"BNVvrCo4sqZejDPE6jmomuN3uRy7GusmUSHTjAnvNb5r"
,"B7DfrYL8KdNiBr1J8WTz3tQmytvjvcDQaA9NQD5v5W3T"
,"5JCdqopqPDX3tjvSUSZLJb1BGc7qNW7F5vUJ5x4tccHf"
,"9mHY2n2s66ZjFAUW8HThGqa9u65CQj1HhKBTPCt9tWk7"
,"Fj15Qa2yFRbywE82Nu2EKd1FzpL1GBAr4nPYaRYv32vL"
,"7iZxPXvcwxNn34TxpHaAVWThFx7e7f12XvuS4h9fw6Y8"
}

@app.route('/', methods=['GET', 'POST'])
def index():
    message = ""
    if request.method == 'POST':
        user_address = request.form.get('address')
        if user_address in WHITELIST:
            message = "You are eligible!"
        else:
            message = "You are not eligible."
    return render_template('index.html', message=message)

if __name__ == '__main__':
    app.run(debug=True)
